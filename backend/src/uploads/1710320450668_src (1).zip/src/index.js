import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { Route, RouterProvider, createBrowserRouter, createRoutesFromElements } from 'react-router-dom'
import Layout from './Layout';
import Home from './components/Home/Home';
import Contact from './components/Contact/Contact';
import 'materialize-css/dist/css/materialize.min.css';
import LoginPage from './components/Siginin/LoginPage';
import SignupPage from './components/SignUp/SignupPage';
import CreateAsset from './components/CreateAsset/CreateAsset';
import User from './admin/components/User/User';
import ProtectedRoute from './routing/ProtectedRoute';
import { Provider } from 'react-redux';
import { persistor, store } from './redux/store';
import { PersistGate } from 'redux-persist/integration/react';


const router = createBrowserRouter(
  createRoutesFromElements(<>
    <Route path="/login" element={<LoginPage />} />
    <Route path="/signup" element={<SignupPage />} />

    <Route path='contact' element={<Contact />} />

    <Route element={<ProtectedRoute />}>
      <Route path='/' element={<Home />} />
      <Route path='home' element={<Home />} />
      <Route path='create-asset' element={<CreateAsset />} />
      <Route path='contact' element={<Contact />} />
      <Route path='user' element={<User />} />
    </Route>
  </>

  )
)


ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <RouterProvider router={router} />
      </PersistGate>
    </Provider>
  </React.StrictMode>,
)

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();