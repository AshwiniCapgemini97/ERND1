import React from 'react';
import { Link } from 'react-router-dom';
import './Breadcrumbs.css';


function Breadcrumbs() {
  return (
    <div className="col s10 m6 l6">
      <h5 className="breadcrumbs-title mt-0 mb-0">Create Assets</h5>
      <ol className="breadcrumbs mb-0">
        <li className="breadcrumb-item"><Link to="/">Home</Link></li>
        <li className="breadcrumb-item"><Link to="/assets">Assets</Link></li>
        <li className="breadcrumb-item active">Create</li>
      </ol>
    </div>
  );
}

export default Breadcrumbs;
