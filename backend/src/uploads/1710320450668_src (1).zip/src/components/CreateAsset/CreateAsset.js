// CardComponent.js
import React, { useState, useEffect, useRef } from 'react';
import './CreateAsset.css';
import MultiSelectDropdown from '../MultiSelectDropdown/MultiSelectDropdown';
import TextArea from '../TextArea/TextArea';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css'; // Import Quill styles
import M from 'materialize-css';
import Loader from '../Loader/Loader';
import GuideLines from '../Guidelines/Guidelines';
import Breadcrumbs from '../Breadcrumb/Breadcrumbs';
// import { useTitle } from '../../context/Title';

const CreateAsset = () => {
    // const { setTitle } = useTitle();
    useEffect(() => {
        // setTitle("Create Asset");

        // Initialize Materialize dropdown
        const elems = document.querySelectorAll('.dropdown-trigger');
        M.Dropdown.init(elems, {});
        // const modalInstance = M.Modal.getInstance(document.getElementById('firstModal'));
        // modalInstance.open(); // Open the modal when the component mounts
    }, []);
    const [optionsTechnologies, setOptionsTechnologies] = useState([]);
    const [optionsSectors, setOptionsSectors] = useState([]);
    const [optionGroups, setoptionGroups] = useState([]);
    const [optionBusinessFunctions, setoptionBusinessFunctions] = useState([]);
    const [optionAssetTypes, setoptionAssetTypes] = useState([]);
    const [optionPortfolios, setoptionPortfolios] = useState([]);
    const [errors, setErrors] = useState({});
    const [loading, setLoading] = useState(false);
    const [logo, setLogo] = useState(null);
    const formRef = useRef(null);
    const [resetDropdownSelection, setResetDropdownSelection] = useState(false);
    useEffect(() => {
        // Function to fetch dropdown options from an API
        const fetchDropdownOptions = async () => {

            try {
                const responseTechnologies = await fetch('http://localhost:3000/api/technologies?page=1&pageSize=5');
                const dataTechnologies = await responseTechnologies.json();
                if (Array.isArray(dataTechnologies?.data)) {
                    const technologies = dataTechnologies.data.map(element => ({
                        value: element.id,
                        title: element.title
                    }));
                    console.log("technologies", technologies);
                    setOptionsTechnologies(technologies);
                }

                const responseSectors = await fetch('http://localhost:3000/api/sectors?page=1&pageSize=5');
                const dataSectors = await responseSectors.json();
                if (Array.isArray(dataSectors?.data)) {
                    const sectors = dataSectors.data.map(element => ({
                        value: element.id,
                        title: element.title
                    }));
                    console.log("sectorssectors", sectors);
                    setOptionsSectors(sectors)
                }

                const responseBusinessFunctions = await fetch('http://localhost:3000/api/business-functions?page=1&pageSize=5');
                const dataBusinessFunctions = await responseBusinessFunctions.json();
                if (Array.isArray(dataBusinessFunctions?.data)) {
                    const businessFunctions = dataBusinessFunctions.data.map(element => ({
                        value: element.id,
                        title: element.title
                    }));
                    setoptionBusinessFunctions(businessFunctions)
                }

                const responseGroups = await fetch('http://localhost:3000/api/groups?page=1&pageSize=5');
                const dataGroups = await responseGroups.json();
                if (Array.isArray(dataGroups?.data)) {
                    const groups = dataGroups.data.map(element => ({
                        value: element.id,
                        title: element.title
                    }));
                    setoptionGroups(groups)
                }

                const responseAssetTypes = await fetch('http://localhost:3000/api/asset-types?page=1&pageSize=5');
                const dataAssetTypes = await responseAssetTypes.json();
                if (Array.isArray(dataAssetTypes?.data)) {
                    const assetTypes = dataAssetTypes.data.map(element => ({
                        value: element.id,
                        title: element.title
                    }));
                    setoptionAssetTypes(assetTypes)
                }
                const responsePortfolios = await fetch('http://localhost:3000/api/portfolios?page=1&pageSize=5');
                const dataPortfolios = await responsePortfolios.json();
                if (Array.isArray(dataPortfolios?.data)) {
                    const portfolios = dataPortfolios.data.map(element => ({
                        value: element.id,
                        title: element.title
                    }));
                    setoptionPortfolios(portfolios)
                }

            } catch (error) {
                console.error('Error fetching dropdown options:', error);
            }
        };

        fetchDropdownOptions();
    }, []);
    const handleFieldFocus = (event) => {
        const { name, value } = event.target;
        console.log("namename", name)
        console.log("valuevalue", value)
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };
    const handleShowToast = () => {
        M.toast({ html: 'Please enter comma separated tags!', classes: 'custom-toast' });
    };
    // const handleOptionClick = (option) => {
    //     const isSelected = selectedOptions.includes(option);
    //     if (isSelected) {
    //         setSelectedOptions(selectedOptions.filter((selected) => selected !== option));
    //     } else {
    //         setSelectedOptions([...selectedOptions, option]);
    //     }
    // };

    const [isDropdownOpen, setIsDropdownOpen] = useState(false);

    // const handleArrowClick = () => {
    //     setIsDropdownOpen(!isDropdownOpen);
    // };

    const handleDocumentClick = (event) => {
        const dropdown = document.querySelector('.dropdown');
        const multiselectField = document.querySelector('.multiselect-field');

        if (multiselectField && multiselectField.contains(event.target)) {
            setIsDropdownOpen(!isDropdownOpen);
        } else if (dropdown && !dropdown.contains(event.target)) {
            setIsDropdownOpen(false);
        }
    };

    useEffect(() => {
        document.addEventListener('click', handleDocumentClick);

        return () => {
            document.removeEventListener('click', handleDocumentClick);
        };
    }, [isDropdownOpen]);
    const handleTextChange = (id, value) => {
        console.log("handleTextChange", id, value)
        setFormData(prevState => ({
            ...prevState,
            [id]: value
        }));
    };
    const handleSubmit = async (e) => {
        console.log("cllefasasdfds");
        e.preventDefault();

        const newErrors = {};
        if (!formData.name) {
            newErrors.name = 'Name is required';
        }
        if (!formData.source_code) {
            newErrors.source_code = 'Source code is required';
        }
        if (formData.asset_portfolios.length === 0) {
            newErrors.asset_portfolios = 'Portfolios are required';
        }
        if (formData.asset_sectors.length === 0) {
            newErrors.asset_sectors = 'Sectors are required';
        }
        if (formData.asset_business.length === 0) {
            newErrors.asset_business = 'Businesses are required';
        }
        if (formData.asset_types.length === 0) {
            newErrors.asset_types = 'Asset Types are required';
        }
        if (formData.asset_groups.length === 0) {
            newErrors.asset_groups = 'Asset Groups are required';
        }
        if (formData.asset_technologies.length === 0) {
            newErrors.asset_technologies = 'Asset Technologies are required';
        }
        if (!formData.short_description) {
            newErrors.short_description = 'Short description is required';
        }
        if (formData.description.replace(/(<([^>]+)>)/gi, '').trim() === '') {
            newErrors.description = 'Description is required';
        }
        if (formData.customer_issues.replace(/(<([^>]+)>)/gi, '').trim() === '') {
            newErrors.customer_issues = 'Customer Issues are required';
        }
        if (formData.benifits.replace(/(<([^>]+)>)/gi, '').trim() === '') {
            newErrors.benifits = 'Benifits are required';
        }
        if (formData.solutions.replace(/(<([^>]+)>)/gi, '').trim() === '') {
            newErrors.solutions = 'Solutions are required';
        }

        if (!formData.logo) {
            newErrors.logo = 'Logo is required';
        }
        if (formData.asset_files.length === 0) {
            newErrors.asset_files = 'Asset files are required';
        }
        setErrors(newErrors);
        const formDataObj = new FormData();

        // Append form data fields
        if (Object.keys(newErrors).length === 0) {
            setLoading(true);
            Object.keys(formData).forEach(key => {
                console.log("Array.isArray(formData[key]", key, Array.isArray(formData[key]))
                if (key === 'logo' || key === 'asset_files') {
                    console.log("key1", key)
                    // Check if the value is a File object
                    if (formData[key] instanceof File) {
                        console.log("keykeykey1", key, formData[key]);
                        formDataObj.append(key, formData[key]);
                    } if (formData[key] instanceof FileList) {
                        // Iterate over the FileList and append each file individually
                        for (let i = 0; i < formData[key].length; i++) {
                            formDataObj.append(key, formData[key][i]);
                        }
                    }
                } else if (key === 'links') {
                    formDataObj.append(key, String(formData[key]));
                } else if (Array.isArray(formData[key])) {
                    // Append array fields individually
                    formData[key].forEach((value, index) => {
                        formDataObj.append(`${key}[${index}]`, value);
                    });
                } else {
                    // Append other form data fields
                    formDataObj.append(key, formData[key]);
                }
            });

            console.log("formDataObjformDataObj", formDataObj);
            const payload = Object.fromEntries(formDataObj);
            console.log("payloadpayload", payload)
            try {
                const response = await fetch('http://localhost:3000/api/assets', {
                    method: 'POST',
                    body: formDataObj // Use FormData object as the body
                });

                if (response.ok) {
                    setLoading(false);
                    M.toast({ html: 'Asset Created Successfully.', classes: 'green' });
                    console.log('API call successful');
                    setResetDropdownSelection(prevState => !prevState);
                    setFormData({
                        name: '',
                        source_code: '',
                        asset_sectors: [],
                        asset_business: [],
                        asset_types: [],
                        asset_portfolios: [],
                        asset_groups: [],
                        asset_technologies: [],
                        tools: '',
                        last_events: '',
                        industry_partnership: '',
                        setup_documentation: '',
                        short_description: '',
                        platform_requirements: '',
                        logistics_information: '',
                        tags: '',
                        description: '',
                        customer_issues: '',
                        benifits: '',
                        solutions: '',
                        logo: '',
                        asset_file_type: 'CONFIDENTIAL',
                        asset_files: [],
                        links: ['', '', '']
                    });
                    const form = formRef.current;
                    console.log("formRef.current", formRef.current);
                    form.elements['logo'].value = '';
                    form.elements['sourcecodename'].value = '';
                    form.elements['logoname'].value = '';
                    form.elements['assetfiles'].value = '';
                    form.elements['links'].value = '';
                    setLogo(null);
                } else {
                    setLoading(false);
                    M.toast({ html: `Something wrong. Please try again.`, classes: 'red' });
                    // Handle API errors
                    console.error('API call failed');
                }
            } catch (error) {
                M.toast({ html: 'Something wrong 1. Please try again.', classes: 'red' });
                setLoading(false);
                console.error('Error occurred while calling API:', error);
            } finally {
                setLoading(false);
            }
        } else {
            M.toast({ html: 'Please fill all the required fields.', classes: 'red' });
        }
    };
    const [formData, setFormData] = useState({
        name: '',
        asset_sectors: [],
        asset_business: [],
        asset_types: [],
        asset_portfolios: [],
        asset_groups: [],
        asset_technologies: [],
        source_code: '',
        tags: '',
        links: ['', '', ''],
        platform_requirements: '',
        logistics_information: '',
        tools: '',
        last_events: '',
        industry_partnership: '',
        setup_documentation: '',
        short_description: '',
        description: '',
        customer_issues: '',
        benifits: '',
        solutions: '',
        logo: '',
        asset_file_type: 'CONFIDENTIAL',
        asset_files: []
    });
    const handleQuillChange = (id, value) => {
        setFormData(prevState => ({
            ...prevState,
            [id]: value
        }));
    };
    const handleDropdownChange = (id, selectedOptions) => {
        console.log("ididid", id);
        console.log("selectedOptionsselectedOptions", selectedOptions);
        console.log("resetDropdownSelection", resetDropdownSelection);

        setFormData(prevValues => ({
            ...prevValues,
            [id]: selectedOptions,
        }));

        if (resetDropdownSelection) {
            setResetDropdownSelection(false); // Reset the resetDropdownSelection state to trigger subsequent resets
        }

    };
    const handleLinksChange = (index, value) => {
        setFormData(prevState => ({
            ...prevState,
            links: [...prevState.links.slice(0, index), value, ...prevState.links.slice(index + 1)]
        }));
        console.log("linkslinks", formData.links);
    };

    const handleAssetFileTypeChange = (e) => {
        setFormData({
            ...formData,
            asset_file_type: e.target.value // Update asset_file_type state with selected value
        });
    };
    const handleLogoUpload = (file) => {
        console.log("handleLogoUpload", file)
        if (file) {
            const reader = new FileReader();
            reader.onload = () => {
                setLogo(reader.result);
            };
            reader.readAsDataURL(file);
        }
        setFormData(prevState => ({
            ...prevState,
            logo: file
        }));
    };
    const handleFileUpload = (files) => {
        console.log("Array.isArray(formData[key])", Array.isArray(files))
        setFormData(prevState => ({
            ...prevState,
            asset_files: files
        }));
    };
    const handleSourceCodeUpload = (file) => {
        console.log("Array.isArray(formData[key])", Array.isArray(file))
        setFormData(prevState => ({
            ...prevState,
            source_code: file
        }));
    };
    return (
        <div>

            <div className='row'>
                <div class="content-wrapper-before admin_banner"></div>
                <div class="breadcrumbs-dark pb-0" id="breadcrumbs-wrapper">
                    <div class="container">
                        <div class="row">
                            <Breadcrumbs />
                        </div>
                    </div>
                </div>
                <div className='col s12'>
                    <div className='container'>
                        <div className='section'>
                            <div class="card">
                                <div class="card-content">
                                    <p class="caption mb-0">Note : <span class="req_star">*</span>Please fill the mandatory fields.
                                        <button className="btn float-right dark-blue accent-4 waves-effect waves-light modal-trigger" href="#guidelines">Guidelines Checklist
                                            <i className="material-icons right">arrow_back</i>
                                        </button>
                                    </p>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <GuideLines />
            <Loader loading={loading} />
            <form ref={formRef} id="asset-create" onSubmit={handleSubmit}>
                <div className="row">
                    <div className="col s12 m8 l8">
                        <div className="row">
                            <div className="col s12">
                                <div className="asset_sidebar wow fadeInRight" data-wow-delay=".2s">
                                    <div className="overlaybg"></div>
                                    <div className="top_title">
                                        <img src="../asset/images/av_icon2.png" className="avatar" alt="Avatar" />
                                        <h4 className="title">Asset Details</h4>
                                    </div>
                                    <div className="bottom_text">
                                        <div class="row">
                                            <div class="input-field col s6">
                                                <input id="name"
                                                    className={errors.name ? 'invalid' : ''}
                                                    name='name'
                                                    value={formData.name}
                                                    onChange={handleFieldFocus} type="text" />
                                                <label for="name">Name <span class="req_star">*</span></label>
                                                <span className="helper-text" data-error={errors.name}></span>
                                            </div>
                                            {/* <div class="input-field col s6">
                                                <input
                                                    name='source_code'
                                                    className={errors.source_code ? 'invalid' : ''}
                                                    value={formData.source_code}
                                                    onChange={handleFieldFocus} id="source_code" type="text" />
                                                <label for="source_code">Source Code <span class="req_star">*</span></label>
                                                <span className="helper-text" data-error={errors.source_code}></span>
                                            </div> */}
                                            <MultiSelectDropdown
                                                id="asset_portfolios"
                                                optionName="asset_portfolios"
                                                dropdownLabel="Asset Portfolios"
                                                options={optionPortfolios}
                                                error={errors.asset_portfolios}
                                                onChange={(selectedOptions) => handleDropdownChange("asset_portfolios", selectedOptions)}
                                                resetSelection={resetDropdownSelection}
                                            />
                                            <span className="helper-textError" data-error={errors.asset_portfolios}></span>
                                        </div>
                                        <div className="row">

                                            <MultiSelectDropdown
                                                id="asset_groups"
                                                optionName="asset_groups"
                                                dropdownLabel="Asset Groups"
                                                options={optionGroups}
                                                error={errors.asset_groups}
                                                focusedField="asset_groups"
                                                onChange={(selectedOptions) => handleDropdownChange("asset_groups", selectedOptions)}
                                                resetSelection={resetDropdownSelection}
                                            />
                                            <MultiSelectDropdown
                                                id="asset_technologies"
                                                optionName="asset_technologies"
                                                dropdownLabel="Asset Technologies"
                                                error={errors.asset_technologies}
                                                options={optionsTechnologies}
                                                onChange={(selectedOptions) => handleDropdownChange("asset_technologies", selectedOptions)}
                                                resetSelection={resetDropdownSelection}
                                            />
                                        </div>
                                        <div className="row">

                                            <MultiSelectDropdown
                                                id="asset_sectors"
                                                optionName="asset_sectors"
                                                dropdownLabel="Asset Sectors"
                                                options={optionsSectors}
                                                focusedField="sector"
                                                error={errors.asset_sectors}
                                                value={formData.asset_sectors}
                                                // selectedValue={formData.sector}
                                                onChange={(selectedOptions) => handleDropdownChange("asset_sectors", selectedOptions)}
                                                resetSelection={resetDropdownSelection}
                                            />
                                            <MultiSelectDropdown
                                                id="asset_business"
                                                optionName="asset_business"
                                                dropdownLabel="Businesses Unit"
                                                error={errors.asset_business}
                                                options={optionBusinessFunctions}
                                                focusedField="asset_business"
                                                onChange={(selectedOptions) => handleDropdownChange("asset_business", selectedOptions)}
                                                resetSelection={resetDropdownSelection}
                                            />
                                        </div>
                                        <div className="row">

                                            <MultiSelectDropdown
                                                id="asset_types"
                                                optionName="asset_types"
                                                dropdownLabel="Asset Types"
                                                error={errors.asset_types}
                                                options={optionAssetTypes}
                                                onChange={(selectedOptions) => handleDropdownChange("asset_types", selectedOptions)}
                                                resetSelection={resetDropdownSelection}
                                            />
                                        </div>
                                        {/* <div className="row">
                                            <div class="input-field col s6">
                                                <label>
                                                    <input type="checkbox" />
                                                    <span>Red</span>
                                                </label>
                                            </div>
                                            <div class="input-field col s6">
                                                <label>
                                                    <input type="checkbox" />
                                                    <span>Red</span>
                                                </label>
                                            </div>
                                            <div class="input-field col s6">
                                                <label>
                                                    <input type="checkbox" />
                                                    <span>Red</span>
                                                </label>
                                            </div>
                                        </div> */}
                                        <div className="row">
                                            <div class="input-field col s6">
                                                <label>
                                                    <input
                                                        name="asset_file_type"
                                                        type="radio"
                                                        value="CONFIDENTIAL"
                                                        checked={formData.asset_file_type === 'CONFIDENTIAL'}
                                                        onChange={handleAssetFileTypeChange}
                                                    />
                                                    <span>Capgemini Confidential</span>
                                                </label>
                                            </div>
                                            <div class="input-field col s6">
                                                <label>
                                                    <input
                                                        name="asset_file_type"
                                                        type="radio"
                                                        value="PUBLIC"
                                                        checked={formData.asset_file_type === 'PUBLIC'}
                                                        onChange={handleAssetFileTypeChange}
                                                    />
                                                    <span>Capgemini Public</span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="asset_sidebar wow fadeInRight" data-wow-delay=".2s">
                                    <div className="overlaybg"></div>
                                    <div className="bottom_text">
                                        <div class="row">
                                            <TextArea id="short_description"
                                                error={errors.short_description}
                                                label="Short Description(Maximum 100 Characters)"
                                                value={formData.short_description}
                                                onChange={(value) => handleTextChange("short_description", value)}
                                            />
                                        </div>
                                        <div class="row">
                                            <div className="col s12 m12 l12">
                                                <label htmlFor="desc">
                                                    <div className="top_title">
                                                        <h6 className="title">Description<span className="req_star">*</span></h6>
                                                    </div>
                                                </label>
                                                <ReactQuill
                                                    name="description"
                                                    theme="snow" // Choose the theme
                                                    value={formData.description}
                                                    onChange={(value) => handleQuillChange('description', value)}
                                                />
                                                {errors.description && <span className="helper-textError">{errors.description}</span>}
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div className="col s12 m12 l12">
                                                <label htmlFor="desc">
                                                    <div className="top_title">
                                                        <h6 className="title">Customer Issues<span className="req_star">*</span></h6>
                                                    </div>
                                                </label>
                                                <ReactQuill
                                                    name="customer_issues"
                                                    theme="snow" // Choose the theme
                                                    value={formData.customer_issues}
                                                    onChange={(value) => handleQuillChange('customer_issues', value)}
                                                />
                                                {errors.customer_issues && <span className="helper-textError">{errors.customer_issues}</span>}
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div className="col s12 m12 l12">
                                                <label htmlFor="desc">
                                                    <div className="top_title">
                                                        <h6 className="title">Benifits<span className="req_star">*</span></h6>
                                                    </div>
                                                </label>
                                                <ReactQuill
                                                    name="benifits"
                                                    theme="snow" // Choose the theme
                                                    value={formData.benifits}
                                                    onChange={(value) => handleQuillChange('benifits', value)}
                                                />
                                                {errors.benifits && <span className="helper-textError">{errors.benifits}</span>}
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div className="col s12 m12 l12">
                                                <label htmlFor="desc">
                                                    <div className="top_title">
                                                        <h6 className="title">Solutions<span className="req_star">*</span></h6>
                                                    </div>
                                                </label>
                                                <ReactQuill
                                                    name="solutions"
                                                    theme="snow" // Choose the theme
                                                    value={formData.solutions}
                                                    onChange={(value) => handleQuillChange('solutions', value)}
                                                />
                                                {errors.solutions && <span className="helper-textError">{errors.solutions}</span>}
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col s12 m4 l4">
                        <div className="row">
                            <div className="col s12">
                                <div className="asset_sidebar wow fadeInRight" data-wow-delay=".2s">
                                    <div className="overlaybg"></div>
                                    <div className="top_title">
                                        <img src="../asset/images/av_icon2.png" className="avatar" alt="Avatar" />
                                        <h4 className="title">Upload Source Code<span class="req_star">*</span></h4>
                                    </div>
                                    <div className="bottom_text">
                                        <div className="row">
                                            <div className="col m12 s12 file-field input-field">
                                                <div className="btn float-right dark-blue accent-4 waves-effect waves-light">
                                                    <span>Choose</span>
                                                    <input type="file"
                                                        onChange={(e) => handleSourceCodeUpload(e.target.files[0])}
                                                        name="source_code" id="source_code" />
                                                </div>
                                                <div className="file-path-wrapper">
                                                    <input id="sourcecodename" name="sourcecodename" className="file-path validate" type="text" readOnly />
                                                </div>
                                                {/* <span style="{{font-size:10px,color:red,float:right;font-weight:bold;"}}>Each file size should be &lt;100MB</span> */}
                                                {errors.source_code && <span className="helper-textError">{errors.source_code}</span>}
                                            </div>


                                        </div>
                                    </div>
                                </div>
                                <div className="asset_sidebar wow fadeInRight" data-wow-delay=".2s">
                                    <div className="overlaybg"></div>
                                    <div className="top_title">
                                        <img src="../asset/images/av_icon2.png" className="avatar" alt="Avatar" />
                                        <h4 className="title">Upload Logo<span class="req_star">*</span></h4>
                                    </div>
                                    <div className="bottom_text">
                                        <div className="row">
                                            <div className="col m12 s12 file-field input-field">
                                                {logo && (
                                                    <img src={logo} alt="Logo" style={{ width: '100%', height: '170px' }} />
                                                )}

                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col m12 s12 file-field input-field">
                                                <div className="btn float-right dark-blue accent-4 waves-effect waves-light">
                                                    <span>Choose</span>
                                                    <input type="file"
                                                        onChange={(e) => handleLogoUpload(e.target.files[0])}
                                                        accept="image/*" name="logo" id="logo" />
                                                </div>
                                                <div className="file-path-wrapper">
                                                    <input id="logoname" name="logoname" className="file-path validate" type="text" readOnly />
                                                </div>
                                                {errors.logo && <span className="helper-textError">{errors.logo}</span>}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="asset_sidebar wow fadeInRight" data-wow-delay=".2s">
                                    <div className="overlaybg"></div>
                                    <div className="top_title">
                                        <img src="../asset/images/av_icon2.png" className="avatar" alt="Avatar" />
                                        <h4 className="title">Upload Files<span class="req_star">*</span></h4>
                                    </div>
                                    <div className="bottom_text">
                                        <div className="row">
                                            <div className="col m12 s12 file-field input-field">
                                                <div className="btn float-right dark-blue accent-4 waves-effect waves-light">
                                                    <span>Choose</span>
                                                    <input type="file" multiple
                                                        onChange={(e) => handleFileUpload(e.target.files)}
                                                        name="asset_files" id="asset_files" />
                                                </div>
                                                <div className="file-path-wrapper">
                                                    <input id="assetfiles" name="assetfiles" className="file-path validate" type="text" readOnly />
                                                </div>
                                                <span style={{ float: 'right', color: 'red', fontWeight: 'bold', fontSize: 10 }}>
                                                    Each file size should be &lt;100MB
                                                </span>
                                                {/* <span style="{{font-size:10px,color:red,float:right;font-weight:bold;"}}>Each file size should be &lt;100MB</span> */}
                                                {errors.asset_files && <span className="helper-textError">{errors.asset_files}</span>}
                                            </div>


                                        </div>
                                    </div>
                                </div>
                                <div className="asset_sidebar wow fadeInRight" data-wow-delay=".2s">
                                    <div className="overlaybg"></div>
                                    <div className="top_title">
                                        <img src="../asset/images/av_icon2.png" className="avatar" alt="Avatar" />
                                        <h4 className="title">Tags</h4>
                                    </div>
                                    <div className="bottom_text">
                                        <div className="row">
                                            <div className="col m12 s12 file-field input-field">
                                                <div className="file-path-wrapper">
                                                    <input onClick={handleShowToast}
                                                        onChange={handleFieldFocus}
                                                        value={formData.tags} id="tags" name="tags" className="file-path validate" type="text" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="asset_sidebar wow fadeInRight" data-wow-delay=".2s">
                                    <div className="overlaybg"></div>
                                    <div className="top_title">
                                        <img src="../asset/images/av_icon2.png" className="avatar" alt="Avatar" />
                                        <h4 className="title">Links</h4>
                                    </div>
                                    <div className="bottom_text">
                                        <div className="row">
                                            ,<div className="col m12 s12 file-field input-field">
                                                <div className="file-path-wrapper">
                                                    <input name="links"
                                                        onChange={(e) => handleLinksChange(0, e.target.value)}
                                                        value={formData.links[0]}
                                                        className="file-path validate" type="text" />
                                                </div>
                                                <div className="file-path-wrapper">
                                                    <input name="links"
                                                        value={formData.links[1]}
                                                        onChange={(e) => handleLinksChange(1, e.target.value)}
                                                        className="file-path validate" type="text" />
                                                </div>
                                                <div className="file-path-wrapper">
                                                    <input name="links"
                                                        value={formData.links[2]}
                                                        onChange={(e) => handleLinksChange(2, e.target.value)}
                                                        className="file-path validate" type="text" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="asset_sidebar wow fadeInRight" data-wow-delay=".2s">
                                    <div className="overlaybg"></div>
                                    <div className="top_title">
                                        <img src="../asset/images/av_icon2.png" className="avatar" alt="Avatar" />
                                        <h4 className="title">Platform Requirements</h4>
                                    </div>
                                    <div className="bottom_text">
                                        <div className="row">
                                            <TextArea id="platform_requirements"
                                                // label="Platform Requirements"
                                                value={formData.platform_requirements}
                                                onChange={(value) => handleTextChange("platform_requirements", value)}
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div className="asset_sidebar wow fadeInRight" data-wow-delay=".2s">
                                    <div className="overlaybg"></div>
                                    <div className="top_title">
                                        <img src="../asset/images/av_icon2.png" className="avatar" alt="Avatar" />
                                        <h4 className="title">Logistics Information</h4>
                                    </div>
                                    <div className="bottom_text">
                                        <div className="row">
                                            <TextArea id="logistics_information"
                                                // label="Logistics Information"
                                                value={formData.logistics_information}
                                                onChange={(value) => handleTextChange("logistics_information", value)}
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div className="asset_sidebar wow fadeInRight" data-wow-delay=".2s">
                                    <div className="overlaybg"></div>
                                    <div className="top_title">
                                        <img src="../asset/images/av_icon2.png" className="avatar" alt="Avatar" />
                                        <h4 className="title">Tools</h4>
                                    </div>
                                    <div className="bottom_text">
                                        <div className="row">
                                            <TextArea id="tools"
                                                // label="Tools"
                                                value={formData.tools}
                                                onChange={(value) => handleTextChange("tools", value)}
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div className="asset_sidebar wow fadeInRight" data-wow-delay=".2s">
                                    <div className="overlaybg"></div>
                                    <div className="top_title">
                                        <img src="../asset/images/av_icon2.png" className="avatar" alt="Avatar" />
                                        <h4 className="title">Last Events</h4>
                                    </div>
                                    <div className="bottom_text">
                                        <div className="row">
                                            <TextArea id="last_events"
                                                // label="Last Events"
                                                value={formData.last_events}
                                                onChange={(value) => handleTextChange("last_events", value)}
                                            />

                                        </div>
                                    </div>
                                </div>

                                <div className="asset_sidebar wow fadeInRight" data-wow-delay=".2s">
                                    <div className="overlaybg"></div>
                                    <div className="top_title">
                                        <img src="../asset/images/av_icon2.png" className="avatar" alt="Avatar" />
                                        <h4 className="title">Industry Partnerships</h4>
                                    </div>
                                    <div className="bottom_text">
                                        <div className="row">
                                            <TextArea id="industry_partnership"
                                                // label="Industry Partnerships"
                                                value={formData.industry_partnership}
                                                onChange={(value) => handleTextChange("industry_partnership", value)}
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div className="asset_sidebar wow fadeInRight" data-wow-delay=".2s">
                                    <div className="overlaybg"></div>
                                    <div className="top_title">
                                        <img src="../asset/images/av_icon2.png" className="avatar" alt="Avatar" />
                                        <h4 className="title">Setup Documentation</h4>
                                    </div>
                                    <div className="bottom_text">
                                        <div className="row">
                                            <TextArea id="setup_documentation"
                                                // label="Setup Documentation"
                                                value={formData.setup_documentation}
                                                onChange={(value) => handleTextChange("setup_documentation", value)}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div className="input-field col s12">
                        <button className="btn dark-blue accent-4 waves-effect waves-light right" type="submit" name="action" value="action">
                            Submit
                            <i className="material-icons right">send</i>
                        </button>
                        {/* <button className="btn dark-blue accent-4 waves-effect waves-light right mr-3" type="submit" name="save" value="save">
                    Save
                    <i className="material-icons right">save</i>
                </button>
                <button className="btn grey waves-effect waves-light right mr-2" type="reset" name="clear">
                    Reset
                    <i className="material-icons right">clear</i>
                </button>
                <button className="btn grey waves-effect waves-light right mr-2" onClick={() => window.history.back()} name="clear">
                    Cancel
                    <i className="material-icons right">arrow_back</i>
                </button> */}
                    </div>
                </div>

                <div >

                </div>
            </form>
        </div>

        //      {
        //     loading && (
        //         <div className="progress">
        //             <div className="indeterminate"></div>
        //         </div>
        //     )
        // }
    );
};

export default CreateAsset;
