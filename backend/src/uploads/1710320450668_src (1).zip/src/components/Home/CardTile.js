import React, { useState } from "react";
import "./Cardtile.css";

const CardTile = ({data, heading}) => {
	
  const [startIndex, setStartIndex] = useState(0);
  const itemsPerPage = 4;

  const handleNext = () => {
    const nextIndex = startIndex + itemsPerPage;
    if (nextIndex < data.length) {
      setStartIndex(nextIndex);
    }
  };

  const handlePrev = () => {
    const prevIndex = startIndex - itemsPerPage;
    if (prevIndex >= 0) {
      setStartIndex(prevIndex);
    }
  };

  return (
    <section className="section-padding9 ">
      <div className="container11">
        <div className="row">
          <div className="text-left mb-20">
            <h2 className="section-title">{heading}</h2>
          </div>
            <div className="flex-viewport slider1">
              <ul className="slides1">
                {data
                  .slice(startIndex, startIndex + itemsPerPage)
                  .map((item) => (
                    <li key={item.id}>
                      <a href={`assets_desc.php?assetid=${item.id}`}>
                        <img
                          src={item.imageUrl}
                          className="img-responsive"
                          alt=""
                          draggable="false"
                        />
                      </a>
                      <div className="slide1_text white-bg">
                        <div className="slide1_title titleellipsis">
                          <a href={`assets_desc.php?assetid=${item.id}`}>
                            {item.title}
                          </a>
                        </div>
                        <div className="slide1_byline">
                          <span className="action">
                            <ul className="list-inline1">
                              <li>
                                <i className="fa fa-download"></i>{" "}
                                {item.downloads}
                              </li>
                              <li>
                                <i className="fa fa-eye"></i> {item.views}
                              </li>
                              <li>
                                <i className="fa fa-star"></i> {item.stars}
                              </li>
                            </ul>
                          </span>
                        </div>
                      </div>
                    </li>
                  ))}
              </ul>
			  			          <button className="prev1" onClick={handlePrev} />
          <button className="next1" onClick={handleNext} />
            </div>
        </div>
      </div>
    </section>
  );
};

export default CardTile;
