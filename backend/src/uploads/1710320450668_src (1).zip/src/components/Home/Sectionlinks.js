// Section.js
import React from "react";
import "./Sectionlinks.css";

const Sectionlinks = () => {
  return (
    <section className="section-padding2">
      <div className=" ml-365">
        <div className="text-left mb-20">
          <h2 className="section-title" style={{marginLeft: "34%", fontWeight: 500, marginTop:"15px"}}>Demo Category</h2>
        </div>
        <div className="flexslider">
          <ul className="slides">
            <li>
              <h4>Core AIE</h4>
              <a href="assets.php?did=3">
                <img
                  src="https://innovationtheater.capgemini.com/assets/img/reuse_icon.png"
                  alt="ProfilePicture"
                  className="profile-picture"
                />
              </a>
            </li>
            <li>
              <h4>Reusable AIE</h4>
              <a href="assets.php?did=4">
                <img
                  src="https://innovationtheater.capgemini.com/assets/img/reuse_icon.png"
                  alt="ProfilePicture"
                  className="profile-picture"
                />
              </a>
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
};

export default Sectionlinks;
