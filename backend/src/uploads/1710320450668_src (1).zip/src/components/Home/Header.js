import React, { useState } from "react";
import "./Header.css";

const Header = () => {
  const [isDropdownOpen, setDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setDropdownOpen(!isDropdownOpen);
  };

  const dropdownMenuItems = [
    'My Profile',
    'Dashboard',
    'View Assets',
    'Create Assets',
    'Asset Report',
    'About Innovation Theater',
    'Help',
    'How to upload asset',
    'How to edit/modify asset',
    'Asset review(how it works)'
];


  return (
    <div>
      <div className="header">
        <div className="container">
          <div className="row">
            <div className="col-12 col-sm-2 cell cg-logo">
              <img
                src="https://innovationtheater.capgemini.com/assets/img/cg_logo.png"
                alt="Capgemini Logo"
              />
            </div>
            <div className="col-12 col-sm-2 cell search-bar">
              <input type="text" placeholder="Search..." />
            </div>
            <div className="col-12 col-sm-2 cell logo-brand">
              <img
                src="https://innovationtheater.capgemini.com/assets/img/logo_beta.png"
                alt="Beta Logo"
              />
            </div>
            <div className="col-12 col-sm-2 cell">
              <button className="industry-vault-btn">Industry Vault</button>
            </div>
            <div
              className="col-12 col-sm-4 cell profile-container"
              onClick={toggleDropdown}
            >
              <img
                src="https://innovationtheater.capgemini.com/assets/img/profile_icon.png"
                alt="Profile Icon"
              />
              {isDropdownOpen && (
                <div className="profile-dropdown">
                  <ul>
                                        <li class="username">Hi,  Thangella Anusha</li>
										<li><a class="waves-effect waves-light" data-toggle="modal" data-target="#profile_modal"><span class="glyphicon glyphicon-user" aria-hidden="true"></span> My Profile</a></li>
                                        
                                                      <li><a href="#"><span class="glyphicon glyphicon-th-large" aria-hidden="true"></span> Dashboard</a></li>
                             
                                        <li><a href="#"><span class="glyphicon glyphicon-blackboard" aria-hidden="true"></span> View Assets</a></li>
                                        <li><a href="#"><span class="glyphicon glyphicon glyphicon-plus" aria-hidden="true"></span> Create Assets</a></li>
                                             <li><a href="#"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span> GIRH Create Asset</a></li>
                                            <li><a href="#"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> Asset Report</a></li>
                                         
										<li><a href="#"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span> Cross Sector Downloads</a></li>
                                        
                                        <li><a href="#"><span class="glyphicon glyphicon-info-sign cgcolor" aria-hidden="true"></span> About Innovation Theater</a></li>
                                                                                <li><a href="#"><span class="glyphicon glyphicon-info-sign cgcolor" aria-hidden="true"></span> Help<span class="indicator"><i class="fa fa-angle-right"></i></span></a>
										  <ul class="dropdown">
											<li><a href="#">How to upload asset</a></li>
										    <li><a href="#">How to edit/modify asset</a></li>
											<li><a href="#">Asset review(how it works)</a></li>
											
										  </ul>
										</li>
                                                                            </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
