import React, { useState, useEffect, useCallback } from "react";
import "./Slider.css";

const Slider = ({ images, texts }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [fontColor, setFontColor] = useState("white");
  const [slideAnimation, setSlideAnimation] = useState(true);

  const currentImage = images[currentImageIndex];
  const currentText = texts[currentImageIndex];

  const nextSlide = useCallback(() => {
    const newIndex = (currentImageIndex + 1) % images.length;
    setCurrentImageIndex(newIndex);
    updateFontColor(newIndex);
    setSlideAnimation(true);
  }, [currentImageIndex, images.length]);

  useEffect(() => {
    const interval = setInterval(() => {
      nextSlide();
    }, 5000);
    return () => clearInterval(interval);
  }, [currentImageIndex, nextSlide]);

  const prevSlide = () => {
    const newIndex = (currentImageIndex - 1 + images.length) % images.length;
    setCurrentImageIndex(newIndex);
    updateFontColor(newIndex);
    setSlideAnimation(true);
  };

  const updateFontColor = (index) => {
    if (index === 4 || index === 5) {
      setFontColor("black");
    } else {
      setFontColor("white");
    }
  };

  return (
  <section className="section-padding">
    <div className={`slider ${slideAnimation ? "animate" : ""}`}>
      <div className="textonimage">
        <h3 style={{ color: fontColor }}>{currentText}</h3>
        <img
          className="slides slide-img"
          src={currentImage}
          alt="Images"
          onAnimationEnd={() => setSlideAnimation(false)}
        />
      </div>
      <button className="prev" onClick={prevSlide} />
      <button className="next" onClick={nextSlide} />
    </div>
	</section>
  );
};

export default Slider;
