import React from "react";
import './Dashboard.css';


const extractedData = [
  {
    title: "Most assets uploaded by",
    name: "Kaur, Paramdeep",
	image: "https://innovationtheater.capgemini.com/assets/img/profile_icon.png",
	icon: "fa-upload",
    count: 282,
  },
  {
    title: "Most visited assets by",
    name: "Mukherjee, Pushpal",
		image: "https://innovationtheater.capgemini.com/assets/img/profile_icon.png",
		 icon: "fa-eye",
    count: 3031,
  },
  {
    title: "Most active user",
    name: "Kennedy, Sarah",
		image: "https://innovationtheater.capgemini.com/assets/img/profile_icon.png",
		icon: "fa-user",
    count: 831,
  },
  {
    title: "Most downloaded assets by",
    name: "Schwartz, Bob",
		image: "https://innovationtheater.capgemini.com/assets/img/profile_icon.png",
		 icon: "fa-download",
    count: 213,
  },
];


const Dashboard = () => {
  return (
 <section className=" section-padding-x">
  <div className="container-x">
    <div className="row-x">
      <div className="text-left-x mb-20">
        <h2 className="section-title-x">Leader Dashboard</h2>
      </div>
    </div>
    <div className="flexslider-x">
      <ul className="slides-x">
        {extractedData.map((item, index) => (
          <li key={index}>
            <h4>{item.title}</h4>
            <img
              className="profile-image-x"
              src={item.image}
              draggable="false"
              alt="Profile"
            />
            <div className="slide_text-x white-bg">
              <div className="slide_title titleellipsis">{item.name}</div>
            </div>
<div className="slide_text-x1 white-bg" >
              <div className="slide_byline-x">
                <span className="action-x">
                  <ul className="list-inline-x">
                    <li>
                      <i className={`fa ${item.icon}`}></i> {item.count}
                    </li>
                  </ul>
                </span>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  </div>
</section>

  );
};
export default Dashboard;
