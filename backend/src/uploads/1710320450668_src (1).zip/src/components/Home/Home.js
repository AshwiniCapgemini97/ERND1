import React, { useState } from "react";
import Slider from "./Slider";
import "./Home.css";
import Sectionlinks from "./Sectionlinks";
import CardTile from "./CardTile";
import Dashboard from "./Dashboard";

function Home() {
  const Headings = [
    "Recently Viewed",
    "Recently Added",
    "Most Viewed Assets Per Sector",
  ];
  const data1 = [
    {
      id: 1,
      title: "Sustainability: Fish Tracking",
      downloads: 101,
      views: 426,
      stars: 4,
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/687905pic1.jpg",
    },
    {
      id: 2,
      title: "Smart Inventory Audit",
      downloads: 120,
      views: 414,
      stars: 5,
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/943910warehouse_drones_ready_for_digital_inventory_management_wide.jpg",
    },
    {
      id: 3,
      title: "Cybersecurity showcased in VR",
      downloads: 17,
      views: 45,
      stars: 0,
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/178734logo_bugBountyVR2.jpg",
    },
    {
      id: 4,
      title: "Memomatic",
      downloads: 12,
      views: 45,
      stars: 0,
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/325235Memomatic.jpg",
    },
    {
      id: 5,
      title: "Smart Container",
      downloads: 259,
      views: 705,
      stars: 5,
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/598253container.jpeg",
    },
    {
      id: 6,
      title: "Road safety system with computer vision",
      downloads: 30,
      views: 79,
      stars: 0,
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/319297Road safety system with computer vision.jpg",
    },
  ];

  const data2 = [
    {
      id: 1,
      title: "Lina - Virtual inviter",
      downloads: 13,
      views: 19,
      stars: 0,
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/37436Lina.jpg",
    },
    {
      id: 2,
      title: "Kai - Goldman Sachs IT Support",
      downloads: 6,
      views: 15,
      stars: 0,
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/599824Kai.jpg",
    },
    {
      id: 3,
      title: "Orange PoC",
      downloads: 26,
      views: 66,
      stars: 5,
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/362118Orange POC.jpg",
    },
    {
      id: 4,
      title: "RHB_Data Mirgration Testing Script",
      downloads: 2,
      views: 5,
      stars: 0,
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/930575migration.png",
    },
    {
      id: 5,
      title: "RHB-Data Housekeeping",
      downloads: 0,
      views: 6,
      stars: 0,
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/387935hk.png",
    },
    {
      id: 6,
      title: "Cybersecurity showcased in VR",
      downloads: 17,
      views: 45,
      stars: 0,
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/178734logo_bugBountyVR2.jpg",
    },
    {
      id: 7,
      title: "Urban Digital Twin for Fiber",
      downloads: 37,
      views: 96,
      stars: 5,
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/448024Urban Digital Twin for Fiber.jpg",
    },
    {
      id: 8,
      title: "Storycraft Demo",
      downloads: 16,
      views: 108,
      stars: 0,
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/17204Marite Metsla.jpg",
    },
    {
      id: 9,
      title: "Llama2: QCM Generator",
      downloads: 13,
      views: 126,
      stars: 5,
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/975314Llama2.jpg",
    },
    {
      id: 10,
      title: "Memomatic",
      downloads: 12,
      views: 45,
      stars: 0,
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/325235Memomatic.jpg",
    },
  ];

  const data3 = [
    {
      id: 1,
      title: "Service Excellence using Smart Glass",
      downloads: 215,
      views: 837,
      stars: 4,
      sectors: ["Automotive", "Manufacturing"],
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/778699remote service.jpg",
    },
    {
      id: 2,
      title: "Smart Container",
      downloads: 259,
      views: 705,
      stars: 5,
      sectors: ["Automotive"],
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/598253container.jpeg",
    },
    {
      id: 3,
      title: "Worker Health & Safety",
      downloads: 153,
      views: 519,
      stars: 5,
      sectors: ["Automotive", "Life Sciences", "Manufacturing"],
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/318680worker.png",
    },
    {
      id: 4,
      title: "MySmartFarm",
      downloads: 144,
      views: 479,
      stars: 3,
      sectors: ["Manufacturing"],
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/206267Smart-Agriculture.jpg",
    },
    {
      id: 5,
      title: "Data Anonymization Workbench",
      downloads: 98,
      views: 468,
      stars: 5,
      sectors: [
        "Automotive",
        "CPRD",
        "EUC",
        "FS",
        "Life Sciences",
        "Manufacturing",
        "Public Sector",
        "Services",
        "TMT",
      ],
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/715955download.jpg",
    },
    {
      id: 6,
      title: "Sustainability: Fish Tracking",
      downloads: 101,
      views: 426,
      stars: 4,
      sectors: ["Life Sciences"],
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/687905pic1.jpg",
    },
    {
      id: 7,
      title: "Smart Inventory Audit",
      downloads: 120,
      views: 414,
      stars: 5,
      sectors: ["Automotive", "CPRD", "Manufacturing", "Public Sector"],
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/943910warehouse_drones_ready_for_digital_inventory_management_wide.jpg",
    },
    {
      id: 8,
      title: "Personalized and Multi Language Solution",
      downloads: 103,
      views: 389,
      stars: 5,
      sectors: ["TMT"],
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/354467download.jpg",
    },
    {
      id: 9,
      title: "Worker Safety with AI",
      downloads: 234,
      views: 371,
      stars: 5,
      sectors: ["Manufacturing"],
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/218945Environmental-Safety.png",
    },
    {
      id: 10,
      title: "NextGen Maintenance Platform",
      downloads: 210,
      views: 362,
      stars: 5,
      sectors: ["Automotive", "Manufacturing"],
      imageUrl:
        "https://innovationtheater.capgemini.com/assets/img/banner/209458nextgen logo.png",
    },
  ];

  const images = [
    "https://innovationtheater.capgemini.com/assets/img/banner/slider-1.jpg",
    "https://innovationtheater.capgemini.com/assets/img/banner/slider-2.jpg",
    "https://innovationtheater.capgemini.com/assets/img/banner/slider-3.jpg",
    "https://innovationtheater.capgemini.com/assets/img/banner/slider-4.jpg",
    "https://innovationtheater.capgemini.com/assets/img/banner/slider-5.jpg",
    "https://innovationtheater.capgemini.com/assets/img/banner/slider-6.jpg",
  ];
  const texts = [
    "Empower Exploration and Experimentation",
    "Smart Approach to Nudge Smarter Innovation",
    "The Missing Step to Scale Up",
    "Build a common language of innovation on your team",
    "Adopt an Agile Mindset",
    "Connect the Silos",
  ];
  const sectorText = [
    "Automotive",
    "Manufacturing",
    "CPRD",
    "EUC",
    "TMT",
    "FS",
    "Life Sciences",
    "Public Sector",
    "Services",
    "Automotive",
    "Manufacturing",
    "CPRD",
  ];
  const sectorImage = [
    "https://innovationtheater.capgemini.com/assets/img/sectors/auto_sector.png",
    "https://innovationtheater.capgemini.com/assets/img/sectors/manu_sector.png",
    "https://innovationtheater.capgemini.com/assets/img/sectors/retail_sector.png",
    "https://innovationtheater.capgemini.com/assets/img/sectors/energy_sector.png",
    "https://innovationtheater.capgemini.com/assets/img/sectors/telecom_sector.png",
    "https://innovationtheater.capgemini.com/assets/img/sectors/bcm_sector.png",
    "https://innovationtheater.capgemini.com/assets/img/sectors/ls_sector.png",
    "https://innovationtheater.capgemini.com/assets/img/sectors/public_sector.png",
    "https://innovationtheater.capgemini.com/assets/img/sectors/service_sector.png",
    "https://innovationtheater.capgemini.com/assets/img/sectors/auto_sector.png",
    "https://innovationtheater.capgemini.com/assets/img/sectors/manu_sector.png",
    "https://innovationtheater.capgemini.com/assets/img/sectors/retail_sector.png",
  ];
  const domainText = [
    "AI",
    "AR",
    "Big Data",
    "Blockchain",
    "Cognitive",
    "IoT",
    "Mobile",
    "Wearables",
    "Robotics",
    "Drones",
    "SAP",
    "5G",
  ];

  const domainImage = [
    "https://innovationtheater.capgemini.com/assets/img/tech/ai_img.png",
    "https://innovationtheater.capgemini.com/assets/img/tech/arvr_img.png",
    "https://innovationtheater.capgemini.com/assets/img/tech/bd_img.png",
    "https://innovationtheater.capgemini.com/assets/img/tech/bc_img.png",
    "https://innovationtheater.capgemini.com/assets/img/tech/cb_img.png",
    "https://innovationtheater.capgemini.com/assets/img/tech/iot_img.png",
    "https://innovationtheater.capgemini.com/assets/img/tech/mobile_img.png",
    "https://innovationtheater.capgemini.com/assets/img/tech/wearable_img.png",
    "https://innovationtheater.capgemini.com/assets/img/tech/robotics_img.png",
    "https://innovationtheater.capgemini.com/assets/img/tech/drones_img.png",
    "https://innovationtheater.capgemini.com/assets/img/tech/sap_img.png",
    "https://innovationtheater.capgemini.com/assets/img/tech/5g.png",
  ];

  const [startIndex, setStartIndex] = useState(0);
  const [domainIndex, setDomainIndex] = useState(0);
  const [activeDotIndex, setActiveDotIndex] = useState(0);
  const [activeDotDomainIndex, setActiveDotDomainIndex] = useState(0);

  const renderSectors = (secText, secImage) => {
    const sectors = [];
    for (let i = startIndex; i < startIndex + 6 && i < secText.length; i++) {
      const sector = secText[i];
      const image = secImage[i];
      sectors.push(
        <div
          key={i}
          className={
            "featured-item seo-service" +
            (activeDotIndex === 0 ? " " : " adjusted-sector")
          }
        >
          <a href="assets.php?sid=1">
            <div className="icon">
              <img
                className="img-responsive"
                src={image}
                alt={sector}
                style={{ width: "100px", height: "100px" }}
              />
            </div>
            <div className="desc">
              <h2 style={{ textDecoration: "none", color: "black" }}>
                {sector}
              </h2>
            </div>
          </a>
          <div>
            <div class="content22">
              <a href="assets.php?allid" class="float22">
                <i
                  class="fa fa-search fa-lg"
                  aria-hidden="true"
                  // style="margin-top:20px;"
                ></i>
              </a>
              <div class="label-container3">
                <div class="label-text">Browse Assets</div>
                <i class="fa fa-play label-arrow"></i>
              </div>
            </div>
          </div>
        </div>
      );
    }
    return sectors;
  };

  const renderDomain = (secText, secImage) => {
    const sectors = [];
    for (let i = domainIndex; i < domainIndex + 6 && i < secText.length; i++) {
      const sector = secText[i];
      const image = secImage[i];
      sectors.push(
        <div key={i} className="featured-item seo-service">
          <a href="assets.php?sid=1">
            <div className="icon">
              <img
                className="img-responsive"
                src={image}
                alt={sector}
                style={{ width: "100px", height: "100px" }}
              />
            </div>
            <div className="desc">
              <h2 style={{ textDecoration: "none", color: "black" }}>
                {sector}
              </h2>
            </div>
          </a>
        </div>
      );
    }
    return sectors;
  };

  const showNextSectors = () => {
    if (activeDotIndex !== 1) {
      setStartIndex((prevIndex) => (prevIndex + 6 >= 12 ? 0 : prevIndex + 6));
      setActiveDotIndex((prevIndex) => (prevIndex + 1) % 2);
    }
  };

  const showPreviousSectors = () => {
    setStartIndex((prevIndex) => (prevIndex - 6 < 0 ? 0 : prevIndex - 6));
    setActiveDotIndex((prevIndex) => (prevIndex - 1 < 0 ? 1 : prevIndex - 1));
  };

  const showNextdomains = () => {
    if (activeDotDomainIndex !== 1) {
      setDomainIndex((prevIndex) => (prevIndex + 6 >= 12 ? 0 : prevIndex + 6));
      setActiveDotDomainIndex((prevIndex) => (prevIndex + 1) % 2);
    }
  };

  const showPreviousdomains = () => {
    setDomainIndex((prevIndex) => (prevIndex - 6 < 0 ? 0 : prevIndex - 6));
    setActiveDotDomainIndex((prevIndex) =>
      prevIndex - 1 < 0 ? 1 : prevIndex - 1
    );
  };

  return (
    <div className="home-wrapper">
      <div className="home-container">
        <Slider images={images} texts={texts} />
        <div className="container">
          <div className="text-left mb-20">
            <ul className="special-text">
              <li>
                <span className="diamond"></span> With Smarter Experimentations
                comes Smarter Innovations
              </li>
              <li>
                <span className="diamond"></span> Bridging the gaps with an
                agile mindset
              </li>
            </ul>
            <h2 className="section-title">Sectors</h2>
          </div>
          <div
            id="sector-carousel"
            className="seo-featured-carousel  brand-dot"
            style={{
              transform: `translateX(-${startIndex * -100}px)`,
              transition: "transform 0.5s ease",
            }}
          >
            {renderSectors(sectorText, sectorImage)}
          </div>
          <div className="owl-dots">
            <div
              className={"owl-dot" + (activeDotIndex === 0 ? " active" : "")}
              onClick={showPreviousSectors}
            ></div>
            <div
              className={"owl-dot" + (activeDotIndex === 1 ? " active" : "")}
              onClick={showNextSectors}
            ></div>
          </div>
          <section className="section-padding">
            <div className="text-left mb-20">
              <ul className="special-text">
                <li>Hold on to your ‘Ticket to Transform’ and explore:</li>
                <li>
                  <span className="diamond"></span> POCs & POV’s,
                </li>
                <li>
                  <span className="diamond"></span> Starter Kits,
                </li>
                <li>
                  <span className="diamond"></span> Business Cases,
                </li>
                <li>
                  <span className="diamond"></span> Reusable building blocks &
                  Innovations across the Group.
                </li>
                <li>
                  <span className="diamond"></span> Discover innovation assets
                  uploaded across industries to increase Group Collaboration and
                  accelerate innovation delivery.
                </li>
              </ul>
            </div>
          </section>
        </div>
        <section class="section-padding gray-bg">
          <div className="container">
            <div class="text-left mb-20">
              <h2 class="section-title">Technology Domain</h2>
            </div>
            <div
              id="sector-carousel"
              className="seo-featured-carousel  brand-dot"
              style={{
                transform: `translateX(-${domainIndex * -100}px)`,
                transition: "transform 0.5s ease",
              }}
            >
              {renderDomain(domainText, domainImage)}
            </div>
            <div className="owl-dots">
              <div
                className={
                  "owl-dot" + (activeDotDomainIndex === 0 ? " active" : "")
                }
                onClick={showPreviousdomains}
              ></div>
              <div
                className={
                  "owl-dot" + (activeDotDomainIndex === 1 ? " active" : "")
                }
                onClick={showNextdomains}
              ></div>
            </div>
            <div className="text-left mb-20">
              <ul className="special-text">
                <li>
                  <span className="diamond"></span> Empower yourself with New
                  Ideas!!
                </li>
                <li>
                  <span className="diamond"></span> Explore & Co-Innovate!!
                </li>
                <li>
                  <span className="diamond"></span> Experiment and
                  co-orchestrate with your innovations!!!
                </li>
              </ul>
            </div>
          </div>
        </section>
        <Sectionlinks />
        <a href="assets.php?did=4">
          <section className="section-padding3">
            <div className="container">
              <div className="text-left">
                <h2 className="section-title3">
                  GENIE Recommendations For You
                </h2>
              </div>

              <div className="row">
                <div id="content"></div>
              </div>
            </div>
          </section>
        </a>
        <CardTile data={data1} heading={Headings[0]} />
        <CardTile data={data2} heading={Headings[1]} />
        <CardTile data={data3} heading={Headings[0]} />
        <Dashboard />
        <div class="AboutUs-sidebar AboutUs-sidebar-collapsed">
          <p class="AboutUs-sidebar-content">
            <a href="aboutus.php" class="aboutus-page">
              <b>About Us</b>
            </a>
          </p>
        </div>
        <div class="infographics-sidebar infographics-sidebar-collapsed">
          <p class="infographics-sidebar-content">
            <a
              href="aboutus.php"
              class="infographics-popup open-popup"
              data-id="popup_default"
            >
              <b>Infographics</b>
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Home;
