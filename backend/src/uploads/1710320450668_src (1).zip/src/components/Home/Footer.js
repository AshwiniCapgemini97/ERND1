import React from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowUp } from '@fortawesome/free-solid-svg-icons';
import "./Footer.css";

const Footer = () => {
  return (
    <div className="footer">
      <div className="container">
        <div className="row">
          <div className="col-12 col-sm-2 cell1 cg-footer-logo">
            <img
              src="https://innovationtheater.capgemini.com/assets/img/cg_logo.png"
              alt="Capgemini Logo"
            />
          </div>
          <div className="col-12 col-sm-8 footer-text">
            All rights reserved by Capgemini. Copyright © 2019
          </div>
		   <a href="#top" class="page-scroll" data-section="#top">
          <div className="scroll-t">
		 
            <p className="footer-top text">Top <FontAwesomeIcon icon={faArrowUp} /></p>
			
			
          </div>
		  
			 </a>
        </div>
      </div>
    </div>
  );
};

export default Footer;
