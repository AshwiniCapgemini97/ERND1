
import React from 'react';
const TextArea = ({ id, label, value, onChange, error }) => {
    const handleChange = (event) => {
        onChange(event.target.value);
    };
    return (
        <div className={`col s12 m12 l12 ${error ? 'invalid' : ''}`}>
            {label && <label htmlFor="desc">
                <div className="top_title">
                    <h6 className="title">{label}<span className="req_star">*</span></h6>
                </div>
            </label>
            }
            <textarea id={id} onChange={handleChange} value={value} style={{ height: '100px', width: '100%' }} maxLength="100" cols="50"></textarea>
            {error && <span className="helper-textError">{error}</span>}
        </div>
    );
};

export default TextArea;
