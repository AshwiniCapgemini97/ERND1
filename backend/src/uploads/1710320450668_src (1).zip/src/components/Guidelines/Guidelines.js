import React, { useEffect } from 'react';
import M from 'materialize-css';

const GuideLines = () => {
    useEffect(() => {

        // Ensure Materialize initialization is executed after the DOM has fully loaded
        document.addEventListener('DOMContentLoaded', function () {
            const firstModal = document.getElementById('firstModal');
            const modalInstance = M.Modal.init(firstModal);
            modalInstance.open();
            return () => {
                modalInstance.destroy();
            };
            // const secondModal = document.getElementById('secondModal');
            // M.Modal.init(secondModal, { dismissible: false });
        });
    }, []);
    const openGuidelinesModal = () => {
        document.addEventListener('DOMContentLoaded', function () {
            const secondModal = document.getElementById('secondModal');
            const modalInstance1 = M.Modal.init(secondModal, { dismissible: false });
            modalInstance1.open();
        })
    };
    return (
        <div>
            <div id="firstModal" className="modal">
                <div className="modal-content">
                    <p>"Please refer Guidelines Checklist before uploading Asset into Innovation Theater".</p>
                    <button
                        className="waves-effect waves-light btn modal-trigger"
                        onClick={openGuidelinesModal}
                    >
                        Open Guidelines
                    </button>
                </div>
            </div>
            <div id="secondModal" className="modal">
                <div className="modal-content">
                    <h5>Innovation Theater QC / Guidelines Checklist</h5>

                    <table>
                        <thead>
                            <tr>
                                <th>Sr.No</th>
                                <th>Check Point</th>
                                <th>Description</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>Asset Name</td>
                                <td>Describe what Asset name is should be consistent and descriptive. The name related to branding, Technology domain, and usability</td>
                            </tr>

                            <tr>
                                <td>2</td>
                                <td>Description</td>
                                <td>Describe about the Asset details. The description should be easily understood. E.g. Asset belongs to which sector, what kind of customers it can be used, or technology domain, or any benchmarking with other demos</td>
                            </tr>

                            <tr>
                                <td>3</td>
                                <td>Customer Issue</td>
                                <td>Describe what the asset will address. E.g. customer challenges, a problem with customer service/product or internal processes</td>
                            </tr>
                            <tr>
                                <td>4</td>
                                <td>Benefits/Solutions</td>
                                <td>Describe reasons a product or service is valuable to a customer. The details about the solution provided by Capgemini that meet new requirements, unarticulated needs or existing customer needs</td>
                            </tr>
                            <tr>
                                <td>5</td>
                                <td>Deployment/Solutions</td>
                                <td>Describe about the how POC / Innovation helps customer their business or service. Also add details about how to install solution in the system (Solution Implementation Instructions). E.G. What hardware, what software, procedures etc.</td>
                            </tr>
                            <tr>
                                <td>6</td>
                                <td>Logo</td>
                                <td>Describe the unique identity of the Asset and what it represents. The Logo should be simple, clear and high in resolution</td>
                            </tr>
                            <tr>
                                <td>7</td>
                                <td>Files</td>
                                <td>Describe a collection of data stored in one unit, identified by an asset name. It can be a document, picture, audio or video stream. The file format should be in .pdf, .ppt and/or video file</td>
                            </tr>
                            <tr>
                                <td>8</td>
                                <td>Links</td>
                                <td>Describe the link for the source code. E.G. Github or link for the asset uploaded on another store</td>
                            </tr>

                        </tbody>
                    </table>
                    <p style={{ color: 'red', fontSize: '12px' }}>* The Asset details and support document should not contain any project id/name, customer name, logo, contact number or email id</p>

                    {/* <p>
                    <label>
                        <input type="checkbox" id="agree-checkbox" />
                        <span>I agree to the terms and conditions</span>
                    </label>
                </p> */}
                </div>
                <div className="modal-footer">
                    <a href="#!" className="modal-close btn waves-effect waves-green" id="modal-close-btn">Agree</a>
                </div>
            </div>
        </div>

    );
};

export default GuideLines;
