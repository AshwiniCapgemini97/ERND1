import React, { useState, useEffect } from 'react';
import M from 'materialize-css';

const MultiSelectDropdown = ({ id, dropdownLabel, options, optionName, onChange, error, resetSelection }) => {
    console.log("error", error);
    console.log("resetSelection", resetSelection);
    const [selectedValues, setSelectedValues] = useState([]);
    console.log("selectedValuesselectedValues", selectedValues)
    useEffect(() => {
        console.log("in the useEffect", selectedValues)
        console.log("in the useEffect resetSelection", resetSelection)
        console.log("in the useEffect dropdownLabel", dropdownLabel)
        // Reset selected options when resetSelection flag changes
        if (resetSelection) {
            console.log("inside the resetSelection", resetSelection)
            setSelectedValues([]);
            initializeMaterializeSelect();
            console.log("inside the selectedValues", selectedValues)

        }
        initializeMaterializeSelect();
    }, [id ,resetSelection]);
   
    const initializeMaterializeSelect = () => {
        const selectElement = document.getElementById(id);
        console.log("selectElement",selectElement);
        M.FormSelect.init(selectElement, {
            dropdownOptions: {
                coverTrigger: false // Optional: Ensure the dropdown menu is not covered by other elements
            }
        });
    };
    useEffect(() => {
        // Initialize Materialize select element
        const selectElement = document.getElementById(id);
        M.FormSelect.init(selectElement, {
            dropdownOptions: {
                coverTrigger: false // Optional: Ensure the dropdown menu is not covered by other elements
            }
        });

        // Update selected values when the select element changes
        const handleChange = () => {
            const selectedOptions = Array.from(selectElement.selectedOptions).map(option => option.value);
            setSelectedValues(selectedOptions);
            console.log("setSelectedValues", selectedValues)
            // Call the onChange callback with the selected values
            onChange(selectedOptions);
        };
        selectElement.addEventListener('change', handleChange);

        // Clean up event listener on component unmount
        return () => {
            selectElement.removeEventListener('change', handleChange);
        };
    }, [id, onChange]);

    return (
        <div className={`input-field col s6 ${error ? 'invalid' : ''}`}>
            <select id={id} multiple value={selectedValues} name={optionName}>
                <option value="" disabled>Select {dropdownLabel}</option>
                {options.map((option) => (
                    <option key={option.value} value={option.value}>{option.title}</option>
                ))}
            </select>
            <label>Select {dropdownLabel} <span class="req_star">*</span></label>
            {error && <span className="helper-text">{error}</span>}
        </div>
    );
};

export default MultiSelectDropdown;
