// ProfileDetailsCard.js
import React, { useState, useRef, useEffect } from 'react';
import {Link, useNavigate} from 'react-router-dom';
import '../CreateAsset/CreateAsset.css';

import M from 'materialize-css';
import GuideLines from '../Guidelines/Guidelines';
import Breadcrumbs from '../Breadcrumb/Breadcrumbs';
import Loader from '../Loader/Loader';
import { isEmail, isValidPassowrd } from '../../utility/FormUtils';
import { useSelector } from 'react-redux';
import Header from '../Header/Header';
import Footer from '../Footer/Footer';

const SignupPage = ({ onClose }) => {
  const [focusedField, setFocusedField] = useState(null);  
  const [loading, setLoading] = useState(false);
  const formSignup= useRef(null);
  const [formData, setFormData] = useState({name: '', email: '', confirmpsd: '', psd: ''});


  const { userInfo } = useSelector((state) => state.auth)
  
  const navigate = useNavigate();
  
  useEffect(()=>{
    if (userInfo) {
      navigate('/');  
    }  
  },[userInfo]);


  const [errors, setErrors] = useState({});
  const handleFieldFocus = (event) => {
    console.log(event.target);
    const { name, value } = event.target;
    setFocusedField(name);
    setFormData(prevState => ({
      ...prevState,
      [name]: value
  }));
  };

  const handleFieldBlur = () => {
    setFocusedField(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // const data = new FormData(e.target);
    // console.log(data.get('email'));
       console.log(formData);
    const newErrors = {};
    if (!formData.name) {
        newErrors.name = 'Name is required';
    }
    if (!formData.email) {
      newErrors.email = 'Email is required';
    } else if(!isEmail(formData.email)){
      newErrors.email = 'valid email is required';
    }

    if (!formData.psd) {
      newErrors.psd = 'Password is required';
    } else if(!isValidPassowrd(formData.psd)) {
      newErrors.psd = 'Password should be of min 8 alphanumeric characters with special characters $_!@';
    }

    if (!formData.confirmpsd) {
      newErrors.confirmpsd = 'Confirm password is required';
    } else if (formData.confirmpsd !== formData.psd) {
      newErrors.confirmpsd = 'Password and Confirm password not matching';
    }

    setErrors(newErrors);
        //const formDataObj = new FormData();

        // Append form data fields
        if (Object.keys(newErrors).length === 0) {
          setLoading(true);
          console.log(formData);
          const payload = {name: formData.name, email: formData.email, password: formData.psd};
            console.log("payloadpayload", payload)
            try {
                const response = await fetch('http://localhost:3000/api/users/signup', {
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(payload),
                   method: 'POST',                    
                    // body: payload // Use FormData object as the body
                });

                if (response.ok) {
                    if (formSignup.current) {
                      formSignup.current.reset();
                    };
                    setLoading(false);
                    M.toast({ html: 'Successfully created your account.', classes: 'green' });
                    // Handle successful API response
                    console.log('API call successful');
                } else {
                    setLoading(false);
                    M.toast({ html: `User already exists`, classes: 'red' });
                    // Handle API errors
                    console.log('API call failed');
                }
            } catch (error) {
                M.toast({ html: 'Something wrong. Please try again.', classes: 'red' });
                setLoading(false);
                console.log('Error occurred while calling API:', error);
            } finally {
                setLoading(false);
            }
        } else {
          M.toast({ html: 'Please fill all the required fields.', classes: 'red' });
        }
  };

  return (
    <>
    <Header />
    <div className='row'>
      <div className="content-wrapper-before admin_banner"></div>
      <div className="breadcrumbs-dark pb-0" id="breadcrumbs-wrapper">
            <div className="container">
                <div className="row">
                    {/* <Breadcrumbs /> */}
                </div>
            </div>
        </div>
        
        <div className='col s12'>
            <div className='container'>
                <div className='section'>
                    <div className="card">
                        <div className="card-content">
                            <p className="caption mb-0">Note : <span className="req_star">*</span>Please fill the mandatory fields.
                                <button className="btn float-right dark-blue accent-4 waves-effect waves-light modal-trigger" href="#guidelines">Guidelines Checklist
                                    <i className="material-icons right">arrow_back</i>
                                </button>
                            </p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <GuideLines />
      <Loader loading={loading} />
    <div className='row'>
      <div className="card-container">
      <div className="profile-details-card">
        <div className="card-header">
          <span className="panel-title">Sign Up</span>
          
        </div>
        <form ref={formSignup} id="asset-create" onSubmit={handleSubmit}>
          <div className="card-body">
            {/* Name Field */}
            <div className="input-field">
                <input id="name"
                    className={errors.name ? 'invalid' : ''}
                    name='name'
                    onChange={handleFieldFocus} type="text" />
                <label>Name <span className="req_star">*</span></label>
                <span className="helper-text" data-error={errors.name}></span>
            </div>
            
            {/* Email Field */}
            <div className="input-field">
                <input id="email"
                    className={errors.email ? 'invalid' : ''}
                    name='email'
                    onChange={handleFieldFocus} type="email" />
                <label>Email <span className="req_star">*</span></label>
                <span className="helper-text"  data-error={errors.email}></span>
            </div>
            {/* Password Field */}
            <div className="input-field">
                  <input id="psd"
                      className={errors.psd ? 'invalid' : ''}
                      name='psd'
                      onChange={handleFieldFocus} type="password" />
                  <label>Password <span className="req_star">*</span></label>
                  <span className="helper-text"  data-error={errors.psd}></span>
              </div>

              {/* Password Field */}
            <div className="input-field">
                  <input id="confirmpsd"
                      className={errors.confirmpsd ? 'invalid' : ''}
                      name='confirmpsd'
                      onChange={handleFieldFocus} type="password" />
                  <label>Confirm Password <span className="req_star">*</span></label>
                  <span className="helper-text"  data-error={errors.confirmpsd}></span>
              </div>
              
            
          </div>
          <div className="card-footer">
            <button className="submit-button" >
              Sign Up
            </button>
            <div className="p-4 box mt-3 text-center">
              Already have an account? <Link to="/login">Log In</Link>
            </div>
          </div>
        </form>
      </div>
    </div>
    </div>
    <Footer />
    </>);
};

export default SignupPage;
