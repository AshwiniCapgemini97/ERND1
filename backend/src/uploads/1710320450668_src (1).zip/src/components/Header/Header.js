import React from 'react';
import './Header.css';
import { persistor } from "../../redux/store";
import { useNavigate, Navigate, useHistory, Link } from 'react-router-dom';
import { useSelector } from 'react-redux'
// import { useTitle } from '../../context/Title';



const Header = () => {
    // const { title } = useTitle();
    // console.log("title", title);
    const { userInfo } = useSelector((state) => state.auth)
    // const history = useHistory();
    const navigate = useNavigate();
    const handleLogout = () => {
        persistor.purge();
        //const history = useHistory();
        //history.push('/login');
        navigate("/login");
        //return  <Navigate replace to="/login" />
    }

    const handleNavClick = () => {
        let x = document.getElementById("myTopnav");
        if (x.className === "topnav") {
            x.className += " responsive";
        } else {
            x.className = "topnav";
        }
    }

    return (
        <div>
            <header className="page-topbar" id="header">
                <div className="navbar navbar-fixed">
                    <nav className="navbar-main navbar-color sideNav-lock white shadow">
                        <div className="nav-wrapper">
                            <div className="header-search-wrapper">
                                <a href="">
                                    <img src="../asset/images/cglogo.png" className="headerlogo" />
                                </a>
                            </div>

                            <div className="header-title">
                                <h5 className="purple-text m-0">Create Asset</h5>
                            </div>

                            <ul className="navbar-list right nav-margin">
                                {/* {userInfo && <li><button onClick={handleLogout}>Logout</button></li>} */}
                                {/* <li>
                                    <a className="waves-effect waves-block waves-light profile-button" href="javascript:void(0);">
                                        <span className="avatar-status avatar-online">
                                            <img onerror="this.src='../assets/img/profile_icon.png'" src="../assets/img/profile_icon.png" />
                                        </span>
                                    </a>
                                    </li> */}
                                {userInfo && <li id="myTopnav" className="topnav" >
                                    <div className="dropdowns">
                                        <span className="avatar-status avatar-online dropbtn">
                                            <img onerror="this.src='../asset/images/profile_icon.png'" src="../asset/images/profile_icon.png" />
                                        </span>
                                        {/* <button className="dropbtn">Dropdown</button> */}
                                        <div className="dropdown-contents">
                                            <span className='username'>Hi {userInfo}</span>
                                            {/* <a href="#ff">Link 1</a>
                                            <a href="#fff">Link 2</a> */}
                                            <Link to="create-asset">Create Asset</Link>
                                            <a href="#" onClick={handleLogout}>Logout</a>
                                        </div>
                                    </div>
                                    <a href="javascript:void(0);" style={{ fontSize: '15px' }} className="icon" onClick={handleNavClick}>&#9776;</a>
                                </li>}
                            </ul>
                            {/* <ul className="dropdown-content" id="notifications-dropdown">
                                <li>
                                    <h6>NOTIFICATIONS<span className="new badge">1</span></h6>
                                </li>
                                <li className="divider"></li>
                                <li><a className="grey-text text-darken-2" href="#!"><span className="material-icons icon-bg-circle cyan small">add_shopping_cart</span> A new asset has been placed!</a>
                                    <time className="media-meta" dateTime="2015-06-12T20:50:48+08:00">2 hours ago</time>
                                </li>

                            </ul> */}



                        </div>

                    </nav>
                </div>
            </header>


        </div>
    );
};

export default Header;
