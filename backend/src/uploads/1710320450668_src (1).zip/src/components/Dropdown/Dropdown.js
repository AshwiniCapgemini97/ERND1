// Dropdown.js
import React from 'react';

const Dropdown = ({ id, options, selectedValue, handleChange }) => {
    console.log("optionsteacca",options);
    return (
        <select
            className="form-select"
            id={id}
            value={selectedValue}
            onChange={handleChange}
        >
            <option value="" disabled>Choose here</option>
            {options.map((option) => (
                <option key={option.value} value={option.value}>
                    {option.label}
                </option>
            ))}
        </select>
    );
};

export default Dropdown;
