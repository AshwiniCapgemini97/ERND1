import React from 'react';
import './Footer.css';

const Footer = () => {
    return (
        <footer class="page-footer footer footer-static footer-dark accent-4 gradient-shadow navbar-border navbar-shadow">
            <div class="footer-copyright">
                <div class="container">
                    <span class="hide-on-small-only pt-05">© All rights reserved by Capgemini. Copyright © 2019</span>
                    <span>
                        <a href="#">
                            <img src="../asset/images/cglogo.png" class="footerlogo right" />
                        </a>
                    </span>
                </div>
            </div>
        </footer>
    );
};

export default Footer;