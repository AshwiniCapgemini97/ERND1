import React from 'react';
import './Header.css';
import { persistor } from "../../redux/store";
import { useNavigate, Navigate, useHistory } from 'react-router-dom';
import { useSelector } from 'react-redux'
// import { useTitle } from '../../c-ontext/Title';
const Header = () => {
    // const { title } = useTitle();
    // console.log("title", title);
    const { userInfo } = useSelector((state) => state.auth)
    const navigate = useNavigate();
    const handleLogout = () => {
        persistor.purge();
        //const history = useHistory();
        //history.push('/login');
        return navigate("/login");
        //return  <Navigate replace to="/login" />
    }
    const handleNavClick = () => {
        let x = document.getElementById("myTopnav");
        if (x.className === "topnav") {
            x.className += " responsive";
        } else {
            x.className = "topnav";
        }
    }
    return (
        <div>

            <header class="page-topbar" id="header">
                <div class="navbar navbar-fixed">
                    <nav class="navbar-main navbar-color sideNav-lock white shadow">
                        <div class="nav-wrapper">
                            <div class="header-search-wrapper">
                                <a href="">
                                    <img src="../asset/images/cglogo.png" className="headerlogo" />
                                </a>
                            </div>

                            <div class="header-title">
                                <h5 class="purple-text m-0"></h5>
                            </div>

                            <ul class="navbar-list right">

                                {/* <li><a class="waves-effect waves-block waves-light profile-button" href="javascript:void(0);"><span class="avatar-status avatar-online">
                                    <img src="../assets/img/profile_icon.png" /></span></li> */}
                            </ul>


                            <ul class="dropdown-content" id="notifications-dropdown">
                                <li>
                                    <h6>NOTIFICATIONS<span class="new badge">1</span></h6>
                                </li>
                                <li class="divider"></li>
                                <li><a class="grey-text text-darken-2" href="#!"><span class="material-icons icon-bg-circle cyan small">add_shopping_cart</span> A new asset has been placed!</a>
                                    <time class="media-meta" >2 hours ago</time>
                                </li>

                            </ul>

                        </div>

                    </nav>
                </div>

            </header>
            {/* <Sidebar/> */}
        </div>
    );
};

export default Header;
