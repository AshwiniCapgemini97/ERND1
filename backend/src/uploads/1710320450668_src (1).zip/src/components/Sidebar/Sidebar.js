import React, { useEffect, useState } from 'react';
import M from 'materialize-css/dist/js/materialize.min.js';
import './Sidebar.css';

const Sidebar = () => {
    const [collapsed, setCollapsed] = useState(true); // State to track sidebar collapse

    const handleToggleCollapse = () => {
        setCollapsed(!collapsed); // Toggle the collapsed state
    };
    useEffect(() => {
        // Initialize the sidenav
        const elems = document.querySelectorAll('.sidenav');
        M.Sidenav.init(elems);
    }, []);

    return (
        <aside className="sidenav-main nav-collapsible sidenav-light sidenav-active-square nav-collapsed" style={{ marginRight: '0px', marginLeft: '100%' }}>
            {/* <div className="brand-sidebar">
                <h1 className="logo-wrapper">
                    <a className="brand-logo darken-1" href="../index.php">
                        <img src="../asset/images/atlogo.png" alt="Logo" />
                        <span className="logo-text hide-on-med-and-down">
                            <span style={{ fontSize: '15px' }}>Innovation Theater</span>
                            <span style={{ fontSize: '10px', color: 'grey' }}>(Beta)</span>
                        </span>
                    </a>
                    <a className="navbar-toggler" href="#"><i className="material-icons">radio_button_unchecked</i></a>
                </h1>
            </div> */}
            <ul className="sidenav right-aligned sidenav-collapsible leftside-navigation collapsible sidenav-fixed menu-shadow" id="slide-out" data-menu="menu-navigation" data-collapsible="menu-accordion">
                <li><a className="waves-effect waves-cyan" href="index.php?ma=db"><i className="material-icons cgcolor">dashboard</i><span className="menu-title">Dashboard</span></a></li>
                <li><a className="waves-effect waves-cyan" href="myassets.php?ma=ma"><i className="material-icons cgcolor">dvr</i><span className="menu-title">View Assets</span></a></li>
                <li><a className="active waves-effect waves-cyan" href="create.php?ma=cr"><i className="material-icons cgcolor">playlist_add</i><span className="menu-title">Create Assets</span></a></li>
                <li><a className="waves-effect waves-cyan" href="bulk_upload.php?ma=bu"><i className="material-icons cgcolor">info</i><span className="menu-title">Bulk Upload</span></a></li>
                <li><a className="waves-effect waves-cyan" href="../aboutus.php?ma=as"><i className="material-icons cgcolor">info</i><span className="menu-title">About Innovation Theater</span></a></li>
                <li>
                    <a className="dropdown-trigger" href="#" data-target="dropdown1" onClick={(e) => e.stopPropagation()}>
                        <i className="material-icons cgcolor">help</i>
                        <span className="menu-title">Help<i className="material-icons right">arrow_drop_down</i></span>
                    </a>
                    <ul id="dropdown1" className="dropdown-content" style={{ position: 'relative', float: 'left' }}>
                        <li><a href="assets/How to upload Asset into Innovation Theater.pptx">How to upload asset</a></li>
                        <li><a href="assets/Innovation Theater Upload-Edit Assets Process-v2.pptx">How to edit/modify asset</a></li>
                        <li><a href="assets/Innovation Theater Board Aseet Reviewing Process-v1.pptx">Asset review(how it works)</a></li>
                    </ul>
                </li>
            </ul>
            <div className="navigation-background"></div>
            <a className="sidenav-trigger btn-sidenav-toggle btn-floating btn-medium waves-effect waves-light hide-on-large-only" href="#" data-target="slide-out"><i className="material-icons cgcolor">menu</i></a>
        </aside>
    );
};

export default Sidebar;
