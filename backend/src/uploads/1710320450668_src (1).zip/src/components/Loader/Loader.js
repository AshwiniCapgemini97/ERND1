import React from 'react';
import './Loader.css'; // Import CSS for the loader styles

const Loader = ({ loading }) => {
    console.log("loading",loading)
    return (
        loading && (
            <div className="loader-container">
                <div className="loader-content">
                    <div className="preloader-wrapper big active">
                        <div className="spinner-layer spinner-blue-only">
                            <div className="circle-clipper left">
                                <div className="circle"></div>
                            </div>
                            <div className="gap-patch">
                                <div className="circle"></div>
                            </div>
                            <div className="circle-clipper right">
                                <div className="circle"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    );
};

export default Loader;
