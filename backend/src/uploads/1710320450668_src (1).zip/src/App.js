import './App.css';
// import CreateAssetReport from './CreateAssetReport';
// import { CreateProfileDetails } from './CreateProfileDetails';
// import ProfileDetailsCard from './ProfileDetailsCard';
// import CreateAsset from './CreateAsset';
import CreateAsset from './components/CreateAsset/CreateAsset';
import User from './admin/components/User/User';
// import Header from './Header';

function App() {
  return (
    <div className="App">
      {/* <Header /> */}
      {/* <CreateAssetReport /> */}
      {/* <CreateProfileDetails /> */}
      {/* <CreateAsset /> */}
      <CreateAsset />
      <User />
    </div>
  );
}

export default App;
