import { useEffect } from 'react'
import { useSelector } from 'react-redux'
import { Outlet } from 'react-router-dom'
import { useNavigate } from 'react-router-dom'
import Header from '../components/Header/Header'
import Footer from '../components/Footer/Footer'
import { TitleProvider } from '../context/Title'

const ProtectedRoute = () => {

  console.log(useSelector((state) => state.auth));
  const { userInfo } = useSelector((state) => state.auth)

  const navigate = useNavigate();

  useEffect(() => {
    if (!userInfo) {
      navigate('/login');
    }
  }, [userInfo]);
  // show unauthorized screen if no user is found in redux store
  if (!userInfo) {
    //redirect('/login');g
    //alert("koko");
    //navigate('/login', { replace: true });
    //return (<></>);
    return (
      <div className='unauthorized'>
        <h1>Unauthorized :(</h1>

      </div>
    )
  }

  return (
    // <TitleProvider>
    <>
      <Header />
      <Outlet />
      <Footer />
    </>
    // </TitleProvider>
  )
}

export default ProtectedRoute
