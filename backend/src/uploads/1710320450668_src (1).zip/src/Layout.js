import React from 'react'
import Header from './components/Header/Header'
import Footer from './components/Footer/Footer'
import { Outlet } from 'react-router-dom'
// import { TitleProvider } from './context/Title';
function Layout() {
  return (
    <>
      {/* <TitleProvider> */}
        {/* <Header />
        ppppppppppppppppppp */}
        {/* <Outlet /> */}
        {/* kkkkkkkkkkkkk
        <Footer /> */}
      {/* </TitleProvider> */}
    </>
  )
}

export default Layout