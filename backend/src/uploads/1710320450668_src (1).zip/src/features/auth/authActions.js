import axios from 'axios'
import { createAsyncThunk, createAction } from '@reduxjs/toolkit'

const backendURL =
  process.env.NODE_ENV !== 'production'
    ? 'http://localhost:3000'
    : import.meta.env.VITE_SERVER_URL

export const userLogin = createAsyncThunk(
  'auth/login',
  async ( {email, password} , thunkAPI) => {
    console.log(email);
   // console.log(psd);
    console.log("async");
    try {
      // configure header's Content-Type as JSON
      const config = {
        headers: {
          'Content-Type': 'application/json',
        },
      }

      const payload = {email, password};
      const data = await fetch(`http://localhost:3000/api/auth/login`, { method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).then(resp => {
      console.log(payload);
     return resp.json()
    });
      // store user's token in local storage
      console.log(data);
      //localStorage.setItem('userToken', data.userToken)

      return data
    } catch (error) {
      console.log("rejected");
      console.log(error);
      // return custom error message from API if any
      if (error.response && error.response.data.message) {
        return thunkAPI.rejectWithValue(error.response.data.message)
      } else {
        return thunkAPI.rejectWithValue(error.message)
      }
    }
  }
)

export const registerUser = createAsyncThunk(
  'auth/register',
  async ({ firstName, email, password }, { rejectWithValue }) => {
    try {
      const config = {
        headers: {
          'Content-Type': 'application/json',
        },
      }

      await axios.post(
        `${backendURL}/api/user/register`,
        { firstName, email, password },
        config
      )
    } catch (error) {
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
)

export const logout = createAction("auth/logout");