import { createSlice } from '@reduxjs/toolkit'
import { registerUser, userLogin } from './authActions'

// initialize userToken from local storage
// const userToken = localStorage.getItem('userToken')
//   ? localStorage.getItem('userToken')
//   : null

const initialState = {
  loading: false,
  userInfo: null,
  userToken: null,
  error: null,
  success: false,
}

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    logout: (state) => {
      localStorage.removeItem('userToken') // delete token from storage
      state.loading = false
      state.userInfo = null
      state.userToken = null
      state.error = null
    },
    setCredentials: (state, { payload }) => {
      state.userInfo = payload
    },
  },
  extraReducers: (builder) => {
    // login user
    builder
    .addCase(userLogin.fulfilled, (state, action) => {
      console.log(userLogin);

      if (action.payload.statusCode === 201) {        
        state.userInfo = "User"
        state.userToken = action.payload.token
        state.error = null
        state.loading = false;
      } else {
        state.error = action?.error?.message || "Invalid login details";
        state.loading = false;
      }
      //localStorage.setItem('userToken', action.payload.token)
    })
      .addCase(userLogin.rejected, (state, action) => {
        console.log(action);
        //state.error = action.error.message
        //state.loading = false;
        //state.userInfo= "jjj"
        // action is inferred correctly here if using TS
      })
      .addCase(userLogin.pending, (state, action) => {
        console.log(action);
        //state.error = null
        //state.loading = false;
        //state.userInfo= "jjj"
        // action is inferred correctly here if using TS
      })
      .addCase(logout, (state) => {
        return initialState;
      });
    // [userLogin.pending]: (state) => {
    //   state.loading = true
    //   state.error = null
    // },
    // [userLogin.fulfilled]: (state, { payload }) => {
    //   state.loading = false
    //   state.userInfo = payload
    //   state.userToken = payload.userToken
    // },
    // [userLogin.rejected]: (state, { payload }) => {
    //   state.loading = false
    //   state.error = payload
    // },
    // // register user
    // [registerUser.pending]: (state) => {
    //   state.loading = true
    //   state.error = null
    // },
    // [registerUser.fulfilled]: (state, { payload }) => {
    //   state.loading = false
    //   state.success = true // registration successful
    // },
    // [registerUser.rejected]: (state, { payload }) => {
    //   state.loading = false
    //   state.error = payload
    // },
  },
  selectors: {
    testingSelector: auth => auth.userInfo
  }
})

export const { logout, setCredentials } = authSlice.actions
export const { testingSelector } = authSlice.selectSlice
export default authSlice.reducer
