import React, { useState, useEffect } from 'react';
import M from 'materialize-css';
import axios from 'axios';

const User = () => {
    const [users, setUsers] = useState([]);
    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const dataUsers = await axios.get('http://localhost:3000/api/users/getallUsers');
                console.log("response.data", dataUsers.data.data)
                setUsers(dataUsers?.data.data);
            } catch (error) {
                console.error('Error fetching users:', error);
            }
        };
        fetchUsers();
        M.AutoInit();
    }, []);
    const handleStatusChange = async (id) => {
        try {
            const updatedUsers = [...users];
            const userToUpdate = updatedUsers.find(user => user.id === id);
            if (!userToUpdate) {
                M.toast({ html: 'Id does not exists.', classes: 'red' });
            }
            const newStatus = userToUpdate.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
            // Make API call to update status
            const response = await axios.put(`http://localhost:3000/api/users/${id}/update-status`, { status: newStatus });
            // Handle success
            M.toast({ html: 'Status Updated Successfully.', classes: 'green' });
            userToUpdate.status = newStatus;
            setUsers(updatedUsers);
            // const updatedUser = { ...user, status: newStatus };
        } catch (error) {
            M.toast({ html: error, classes: 'red' });
            // Handle error
            console.error('Error updating status:', error);
            // setNotification({ type: 'error', message: 'Failed to update status.' });
        }
    };
    return (
        <div>
            <table className="striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    {users.map(user => (
                        <tr key={user.id}>
                            <td>{user.id}</td>
                            <td>{user.name}</td>
                            <td>{user.email}</td>
                            <td><button onClick={() => handleStatusChange(user.id, user.status)} className="waves-effect waves-light btn">{user.status}</button>
                            </td>
                            <td>{new Date(user.created_at).toLocaleString()}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default User