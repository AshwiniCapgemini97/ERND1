import React from 'react';
import './Header.css';

const Banner = ({technologyOptions, sectorOptions, selectedTechnology, selectedSector, handleTechnologyChange, handleSectorChange, handleSubmit }) => {
  return (
    <div className="main-content">
        <div className="banner-section">
            <img
            src="https://innovationtheater.capgemini.com/assets/img/banner/auto_banner.jpg"
            alt="Banner Image"
            className="banner-image"
            />
            <div className="banner-text">Generate Asset Report</div>
        </div>

        <div className="card">
            <div className="row">
                <div className="col s12 l6">
                    <label htmlFor="technologyDropdown" className="asset-report-form-label">Technology</label>
                    <select
                    className="form-select"
                    id="technologyDropdown"
                    value={selectedTechnology}
                    onChange={handleTechnologyChange}
                    >
                        <option value="" disabled>Choose here</option>
                        {technologyOptions.map((option) => (
                            <option key={option.id} value={option.value}>
                            {option.label}
                            </option>
                        ))}
                    </select>
                </div>
            </div>
            <div className="row">
                <div className="col s12 l6 sector">
                    <label htmlFor="sectorDropdown" className="asset-report-form-label">Sector</label>
                    <select
                    className="form-select"
                    id="sectorDropdown"
                    value={selectedSector}
                    onChange={handleSectorChange}
                    >
                        <option value="" disabled>Choose here</option>
                        {sectorOptions.map((option) => (
                            <option key={option.id} value={option.value}>
                            {option.label}
                            </option>
                        ))}
                    </select>
                </div>
            </div>
            <div className="row">
                <div className="col s12 l6 sector">
                    <button type="submit" className="asset-report-submit" onClick={handleSubmit}>Submit</button>
                </div>
            </div>
        </div>
    </div>
  );
};

export default Banner;