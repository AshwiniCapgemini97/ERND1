const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
export const isEmail = (email) => emailRegex.test(email);;

const passwordRegx = /^([a-zA-Z0-9@_$!]){6,15}$/;
export const isValidPassowrd = (psd) => passwordRegx.test(psd);;
